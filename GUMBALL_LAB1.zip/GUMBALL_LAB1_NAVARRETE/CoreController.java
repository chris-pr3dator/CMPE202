
public class CoreController extends GumBall
{
    private int coin;
    private int coin_type; 
    public static String coin_name; 
    
    public void setPrice(int unit_price) {
        GumBall.unit_price = unit_price;
    }
   
    public String getCoinName() {
        return CoreController.coin_name;
    }
    
    public boolean AvailableGumballs() {
        
        if (GumballMachine.available_gumballs == 0) {
            System.out.println("AVAILABLE GUMBALLS:" + GumballMachine.available_gumballs);
            return false;
        } else {
            System.out.println("AVAILABLE GUMBALLS:" + GumballMachine.available_gumballs);
            return true;
        }
    }
    
    public boolean CheckCredit(int credit) {    
        if (credit < 50) {
            System.out.println("You have enough credit: " + credit);
            return true;
        } else {
            System.out.println("Not enough credit. Insert more coins...!");
            return false;
        }
    }
    
    // Function to detect Coin-type.
    // The return value will be an integer (coin value)
    
    public String DetectCoinType(int coin)
    {
        
        switch(coin) {
        
        case 25:
            //System.out.println("Coin inserted: Quarter");
            //CoreController.coin_name = "quarter";
            //System.out.println(this.coin_name);
            return "quarter";
        case 10:
            //System.out.println("Coin inserted: Dime");
            return "dime";
        case 5:
            //System.out.println("Coin inserted: Nickel");
            //CoreController.coin_name = "nickel";
            return "nickel";
            
        default:
            //System.out.println("Unknown coin type!");
            //CoreController.coin_name = "unknown";
            return "unknown";
        }
    }
}
