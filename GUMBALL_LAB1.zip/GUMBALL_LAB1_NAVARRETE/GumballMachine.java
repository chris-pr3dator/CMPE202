import java.util.*;
import java.lang.*;

public class GumballMachine extends CoreController    
{
    
    // Machine type 1: Accepts only Quarters
    // Machine type 2: Accepts only Two Quarters
    // Machine type 3: Accepts all coints
    
    public int machine_type;
    public static int credit;
    public static int available_gumballs = 5;

    public GumballMachine(int machine_type)
    {
        this.machine_type = machine_type;
    }
    
    public void eject_coin() {
        System.out.println("O<<|| Ejecting Coin...\n");
        System.out.println("[+] Plase, insert coin....");
    }
    
    public void insertCoin(int coin)
    {
        System.out.println(">>O|| Coin inserted:" + coin); 
        // Increment credit
        GumballMachine.credit = GumballMachine.credit + coin;

        CheckCredit(GumballMachine.credit);

        switch (this.machine_type) {
            case 1:
                // Set the gumball price for machine 1
                GumBall.unit_price = 25;
                break;
                
            case 2:
                // Set the gumball price for machine 2
                GumBall.unit_price = 50;
                //System.out.printf("## Machine Type: 2 (price: %d %s) ##\n", GumBall.unit_price, this.getCoinName());
                break;
                
            case 3:
                // Set the gumball price for machine 2
                GumBall.unit_price = 50;
                //System.out.printf("## Machine Type: 2 (price: %d %s) ##\n", GumBall.unit_price, this.getCoinName());
                break;

            }
        System.out.printf("## Machine Type: %d (price: %d %s) ##\n", this.machine_type, GumBall.unit_price, this.DetectCoinType(coin));
    }
    
    public void turnCrank(int coin)
    {        
        CheckCredit(GumballMachine.credit);

        //if (this.AvailableGumballs() && this.machine_type == 1 &&
        
        if (this.AvailableGumballs()) {
            
            if (this.machine_type == 1) {
                
                if (this.DetectCoinType(coin) == "quarter" && GumballMachine.credit == 25) {
                    System.out.printf("[*] The coin you inserted (%s) is accepted.\n", this.DetectCoinType(coin));
                    
                    System.out.printf("Thanks for your coin. (%d|%s) Gumball Ejected!\n", coin, this.DetectCoinType(coin));
                    
                    // Set credit to zero.
                    GumballMachine.credit = 0;
                    // Decrement number of available gumballs
                    GumballMachine.available_gumballs = GumballMachine.available_gumballs - 1;
                    System.out.println("[+] Plase, insert coin....");
                    
                } else {
                    System.out.printf("[!] The coin you inserted (%s) is NOT accepted.\n", this.DetectCoinType(coin));
                    GumballMachine.credit = 0;
                    eject_coin();
                }
            }
            
            if (this.machine_type == 2) {
               
                if (this.DetectCoinType(coin) == "quarter" && GumballMachine.credit == 25) {
                    System.out.printf("[*] The coin you inserted (%s) is accepted. Need one more quarter...\n", this.DetectCoinType(coin));
                }  
                else if (this.DetectCoinType(coin) == "quarter" && GumballMachine.credit == 50) {
                    System.out.printf("[*] The coin you inserted (%s) is accepted.\n", this.DetectCoinType(coin));
                    System.out.printf("Thanks for your coin. (%d|%s) Gumball Ejected!\n", coin, this.DetectCoinType(coin));
                    
                    // Set credit to zero.
                    GumballMachine.credit = 0;
                    // Decrement number of available gumballs
                    GumballMachine.available_gumballs = GumballMachine.available_gumballs - 1;
                    System.out.println("[+] Plase, insert coin....");
                } else {
                    System.out.printf("[!] The coin you inserted (%s) is NOT accepted.\n", this.DetectCoinType(coin));
                    eject_coin();
                }
            }
            
            if (this.machine_type == 3) {
               
                if (GumballMachine.credit == 50) {
                    System.out.printf("[*] The coin you inserted (%s) is accepted.\n", this.DetectCoinType(coin));
                    System.out.printf("Thanks for your coin. (%d|%s) Gumball Ejected!\n", coin, this.DetectCoinType(coin));
                    
                    // Set credit to zero.
                    GumballMachine.credit = 0;
                    // Decrement number of available gumballs
                    GumballMachine.available_gumballs = GumballMachine.available_gumballs - 1;
                    System.out.println("[+] Plase, insert coin....");
                } else {
                    System.out.printf("[*] The coin you inserted (%s) is accepted. Need one more coins!...\n", this.DetectCoinType(coin));
                }
            }   
                
        // No more gumballs here.
            
        } else {
            System.out.println("[!] No more Gumballs are available. Quit!");
        }    
    }
}
