import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {

        int coin;
        int machine_type = 3;
        System.out.println("[+] Plase, insert coin....");

        // This is a loop simulating waiting for a user inserting a coin.
        Scanner sc = new Scanner(System.in);
                     
        while ((coin = sc.nextInt()) != 0) {
         
            GumballMachine gumballMachine = new GumballMachine(machine_type);
            gumballMachine.insertCoin(coin);
            gumballMachine.turnCrank(coin);
             
        }
        
        System.out.println("Done.");                
    }
}
