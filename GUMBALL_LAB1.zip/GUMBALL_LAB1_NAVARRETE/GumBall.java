public class GumBall
{
    public static int unit_price;

    public void GumBall()
    {
        this.unit_price = unit_price;
    }

}
